// Smooth scroll
function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({
      behavior: "smooth"
        });
        }

        // Footer year
        document.getElementById("year").textContent = new Date().getFullYear();

        // Admission alert
        function showAlert() {
          alert("Admissions form will be available soon.");
          }

          // Active menu on scroll
          const sections = document.querySelectorAll("section");
          const navLinks = document.querySelectorAll(".nav-link");

          window.addEventListener("scroll", () => {
            let current = "";
              sections.forEach(section => {
                  const sectionTop = section.offsetTop - 150;
                      if (scrollY >= sectionTop) {
                            current = section.getAttribute("id");
                                }
                                  });

                                    navLinks.forEach(link => {
                                        link.classList.remove("active");
                                            if (link.getAttribute("href") === "#" + current) {
                                                  link.classList.add("active");
                                                      }
                                                        });
                                                        });